package security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;

public class Security {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getMD5("Az MD5 egy 128 bites, egyir�ny� k�dol�si algoritmus"));

	}
	
	public static String getMD5(String in){

		try{
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(in.getBytes(),0,in.length());
			return new BigInteger(1,md.digest()).toString(16);
		}
		catch (NoSuchAlgorithmException e){
			e.printStackTrace();
			return e.toString();
		}
	}
}
/**
 * https://www.mkyong.com/java/java-sha-hashing-example/
 * http://www.javased.com/index.php?api=java.security.MessageDigest
 * https://www.flexiprovider.de/examples/ExampleDigest.html
 */