package md5hash;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import net.miginfocom.swing.MigLayout;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JFileChooser;

public class MyWindow {

	private JFrame frmMdHashGenerator;
	private JTextField tfPath;
	private JComboBox comboBox;
	private JTextField tfGetHash;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JTextField tfCalcHash;
	private JLabel lblGet;
	private JLabel lblHash;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MyWindow window = new MyWindow();
					window.frmMdHashGenerator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MyWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMdHashGenerator = new JFrame();
		frmMdHashGenerator.getContentPane().setBackground(Color.LIGHT_GRAY);
		frmMdHashGenerator.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 12));
		frmMdHashGenerator.setTitle("MD5 Hash Generator");
		frmMdHashGenerator.setSize(new Dimension(600, 200));
		frmMdHashGenerator.setBounds(100, 100, 451, 166);
		frmMdHashGenerator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMdHashGenerator.getContentPane().setLayout(null);
		
		JLabel lblFile = new JLabel("File:");
		lblFile.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFile.setBounds(10, 12, 35, 14);
		frmMdHashGenerator.getContentPane().add(lblFile);
		
		tfPath = new JTextField();
		tfPath.setFont(new Font("Tahoma", Font.PLAIN, 14));
		tfPath.setBounds(51, 9, 277, 20);
		frmMdHashGenerator.getContentPane().add(tfPath);
		tfPath.setColumns(32);
		
		JButton btnChoose = new JButton("Choose");
		btnChoose.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnChoose.setBounds(335, 9, 89, 23);
		btnChoose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				/* ================== teszteles
				JFileChooser chooser = new JFileChooser();
				/*FileNameExtensionFilter filter = new FileNameExtensionFilter(
				    "TXT files", "txt");
				chooser.setFileFilter(filter);
				chooser.setCurrentDirectory("<YOUR DIR COMES HERE>");

				int returnVal = chooser.showOpenDialog(null);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
				   System.out.println("You chose to open this file: " +
				        chooser.getSelectedFile().getName());
				}
				*/
				//==================
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
				
				int returnVal = fileChooser.showOpenDialog(null);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					tfPath.setText(fileChooser.getSelectedFile().getAbsolutePath());
				}
				
			}
		});
		frmMdHashGenerator.getContentPane().add(btnChoose);
		
		tfGetHash = new JTextField();
		tfGetHash.setFont(new Font("Tahoma", Font.PLAIN, 14));
		tfGetHash.setBounds(51, 38, 277, 20);
		frmMdHashGenerator.getContentPane().add(tfGetHash);
		tfGetHash.setColumns(40);
		
		label = new JLabel("");
		label.setBounds(420, 64, 0, 0);
		frmMdHashGenerator.getContentPane().add(label);
		
		label_1 = new JLabel("");
		label_1.setBounds(424, 64, 0, 0);
		frmMdHashGenerator.getContentPane().add(label_1);
		
		label_2 = new JLabel("");
		label_2.setBounds(428, 64, 0, 0);
		frmMdHashGenerator.getContentPane().add(label_2);
		
		comboBox = new JComboBox();
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 14));
		comboBox.setBounds(335, 38, 89, 20);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"MD5", "SHA-1", "SHA-256"}));
		frmMdHashGenerator.getContentPane().add(comboBox);
		
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCalculate.setBounds(335, 64, 89, 23);
		frmMdHashGenerator.getContentPane().add(btnCalculate);
		
		tfCalcHash = new JTextField();
		tfCalcHash.setBounds(51, 67, 277, 20);
		frmMdHashGenerator.getContentPane().add(tfCalcHash);
		tfCalcHash.setColumns(10);
		
		lblGet = new JLabel("Get:");
		lblGet.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblGet.setBounds(10, 41, 35, 14);
		frmMdHashGenerator.getContentPane().add(lblGet);
		
		lblHash = new JLabel("Hash:");
		lblHash.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblHash.setBounds(10, 68, 35, 14);
		frmMdHashGenerator.getContentPane().add(lblHash);
		
		lblNewLabel = new JLabel("Done. The two hash values are the same.");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBackground(Color.DARK_GRAY);
		lblNewLabel.setBounds(10, 96, 415, 18);
		frmMdHashGenerator.getContentPane().add(lblNewLabel);
	}
}
