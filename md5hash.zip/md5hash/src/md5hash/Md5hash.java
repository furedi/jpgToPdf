package md5hash;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigInteger;
import java.nio.file.Files;

public class Md5hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(getHash("SHA-256","./test.txt"));
		// System.out.println(args[0]+" "+args[1]);
		// System.out.println(getHash(args[0],args[1]));
	}
	
	public static String getHash(String algoritmus,String fname){
		String hashCode = new String();
		try{
			MessageDigest md = MessageDigest.getInstance(algoritmus);
			
			File f = new File(fname);
			FileInputStream fis = new FileInputStream(f);
			byte[] b = new byte[(int)Math.pow(2, 16)];
			int byteNumber = 0;
			while(( byteNumber = fis.read(b, 0, b.length))!=-1){
				md.update(b,0,byteNumber);				
			};
			fis.close();
			
			hashCode = new BigInteger(1,md.digest()).toString(16);
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return hashCode;
	}
}
/**
 * https://www.mkyong.com/java/java-sha-hashing-example/
 * http://www.javased.com/index.php?api=java.security.MessageDigest
 * https://www.flexiprovider.de/examples/ExampleDigest.html
 * 
 * Colors: https://sourceforge.net/projects/quickhash/
 */